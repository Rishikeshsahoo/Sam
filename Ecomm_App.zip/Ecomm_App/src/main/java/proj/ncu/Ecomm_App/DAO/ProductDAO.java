package proj.ncu.Ecomm_App.DAO;

import java.util.List;

import proj.ncu.Ecomm_App.Entity.ProductPOJO;

public interface ProductDAO {
	public List<ProductPOJO> getProductByCategory(String category);
	public int addProduct(ProductPOJO product);
	
}
