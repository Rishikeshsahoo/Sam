package proj.ncu.Ecomm_App.controller;


import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.RequestAttributeMethodArgumentResolver;
import org.springframework.web.servlet.view.RedirectView;

import com.mysql.cj.Session;

import proj.ncu.Ecomm_App.DAO.sellerDAOImpl;
import proj.ncu.Ecomm_App.Entity.SellerPOJO;

@Controller
public class SellerController {
	
	@Autowired
	sellerDAOImpl sellerDAOImp;
	
	@ModelAttribute("sellerPOJO")
	public SellerPOJO getSellerPOJO()
	{
		return new SellerPOJO();
	}
	
	@RequestMapping(value= "/")
	public ModelAndView test(HttpServletResponse response, HttpServletRequest req) throws IOException{
		HttpSession session =req.getSession();
		int id=0;
		System.out.println("this is id "+session.getAttribute("productid"));
		if(session.getAttribute("productid")==null)
		{
			System.out.println("bhaag lode");
			id=0;
		}
		System.out.println(session.getAttribute("productid"));
		session.setAttribute("productid", id);
		return new ModelAndView("home");
	}
	
	@RequestMapping(value= "/userType")
	public String getUserType()
	{
		return "userType";
	}
	
	@RequestMapping(value= "/sellerRegister")
	public String getSellerLogin()
	{
		return "sellerRegister";
	}
	
	@RequestMapping(value= "/sellerView1")
	public RedirectView getSellerConfirm(@ModelAttribute("sellerPOJO") SellerPOJO seller, Model model)
	{
		sellerDAOImp.addSeller(seller);
		List<SellerPOJO> lsp =sellerDAOImp.getSeller("devashishdawgie");
		
		for (SellerPOJO spojo : lsp)
		{
			System.out.println(spojo.getAddress());
		}
		return new RedirectView("sellerView");
	}
	
	
	
}
