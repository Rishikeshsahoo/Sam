package proj.ncu.Ecomm_App.DAO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import proj.ncu.Ecomm_App.Entity.SellerPOJO;
import proj.ncu.Ecomm_App.RowMapper.SellerRowMapper;

@Repository
public class sellerDAOImpl implements sellerDAO{
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<SellerPOJO> getSeller(String username) {
		// TODO Auto-generated method stub
		String query = "select * from Seller where username=?";
		Object[] args = { username };
		List<SellerPOJO> ls = new ArrayList<SellerPOJO>();
		ls = jdbcTemplate.query(query, args, new SellerRowMapper());
		return ls;
	}

	@Override
	public void addSeller(SellerPOJO sellerpojo) {
		// TODO Auto-generated method stub
		String add = "insert into seller values(?,?,?,?)";
		Object[] args = {sellerpojo.getUsername(), sellerpojo.getPassword(), sellerpojo.getAddress(), sellerpojo.getPincode() };
		int addS = jdbcTemplate.update(add, args);
		if (addS == 1)
		{
			System.out.println("Added Successfully!");
		}
		
		else
		{
			System.out.println("Unlucky :clown_face: ");
		}
	}

}
