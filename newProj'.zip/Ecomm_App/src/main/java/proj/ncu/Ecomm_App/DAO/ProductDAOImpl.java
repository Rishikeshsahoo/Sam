package proj.ncu.Ecomm_App.DAO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import proj.ncu.Ecomm_App.Entity.ProductPOJO;
import proj.ncu.Ecomm_App.RowMapper.ProductRowMapper;

@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public List<ProductPOJO> getProductByCategory(String category) {
		String query="select * from products where category=?";
		Object[] args= {category};
		List<ProductPOJO> ls = new ArrayList<ProductPOJO>();
		ls = jdbcTemplate.query(query, args, new ProductRowMapper());
		return ls;
	}
	
	public int getSize() 
	{
		String query="select * from products";
		List<ProductPOJO> ls = new ArrayList<ProductPOJO>();
		ls = jdbcTemplate.query(query, new ProductRowMapper());
		return ls.size();
	}

	@Override
	public int addProduct(ProductPOJO product) {
		String add = "insert into products values(?,?,?,?,?,?,?)";
		Object[] args = {product.getId(), product.getName(), product.getCategory(), product.getPrice(),product.getDescription(),product.getQuantity(),product.getImage() };
		int addS = jdbcTemplate.update(add, args);
		if (addS == 1)
		{
			System.out.println("Added Successfully!");
		}
		
		else
		{
			System.out.println("Unlucky :clown_face: ");
		}
		return 0;
	}

	
}
