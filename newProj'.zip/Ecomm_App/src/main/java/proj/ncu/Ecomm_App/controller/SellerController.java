package proj.ncu.Ecomm_App.controller;


import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.RequestAttributeMethodArgumentResolver;
import org.springframework.web.servlet.view.RedirectView;

import com.mysql.cj.Session;

import proj.ncu.Ecomm_App.DAO.sellerDAOImpl;
import proj.ncu.Ecomm_App.Entity.SellerPOJO;

@Controller
public class SellerController {
	
	@Autowired
	sellerDAOImpl sellerDAOImp;
	
	@ModelAttribute("sellerPOJO")
	public SellerPOJO getSellerPOJO()
	{
		return new SellerPOJO();
	}
	
	@RequestMapping(value= "/")
	public ModelAndView test(HttpServletResponse response, HttpServletRequest req) throws IOException{
		HttpSession session =req.getSession();
		int id=0;
		System.out.println("this is id "+session.getAttribute("productid"));
		if(session.getAttribute("productid")==null)
		{
			System.out.println("bhaag lode");
			id=0;
		}
		System.out.println(session.getAttribute("productid"));
		session.setAttribute("productid", id);
		return new ModelAndView("home");
	}
	
	@RequestMapping(value= "/userType")
	public String getUserType()
	{
		return "userType";
	}
	
	@RequestMapping(value= "/sellerRegister")
	public String getSellerRegister()
	{
		return "sellerRegister";
	}
	
	@RequestMapping(value= "/validateSeller")
	public RedirectView validateseller(@RequestParam("pass")String pass,@RequestParam("username")String username)
	{
		System.out.println(username);
		System.out.println(pass);
		boolean is=sellerDAOImp.validate(username, pass);
		if(is) 
		{
			return new RedirectView("/SpringMvcApp/sellerView2");
		}
		return new RedirectView("/SpringMvcApp/sellerLogin");
	}
	
	@RequestMapping(value= "/sellerLogin")
	public String getSellerLogin()
	{
		return "sellerLogin";
	}
	
	@RequestMapping(value= "/sellerView2")
	public RedirectView getSellerConfirm2()
	{
		return new RedirectView("/SpringMvcApp/sellerView");
	}
	
	@RequestMapping(value= "/sellerView1")
	public RedirectView getSellerConfirm(@ModelAttribute("sellerPOJO") SellerPOJO seller, Model model)
	{
		sellerDAOImp.addSeller(seller);
		
		return new RedirectView("sellerView");
	}
	
	
	
}
