package proj.ncu.Ecomm_App.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.RedirectView;

import proj.ncu.Ecomm_App.DAO.ProductDAOImpl;
import proj.ncu.Ecomm_App.DAO.sellerDAOImpl;
import proj.ncu.Ecomm_App.Entity.ProductPOJO;
import proj.ncu.Ecomm_App.Entity.SellerPOJO;

@Controller
@MultipartConfig

public class ProductController {

	@Autowired
	ProductDAOImpl productDAOImpl;
	
	@ModelAttribute("productPOJO")
	ProductPOJO getSellerPOJO()
	{
		return new ProductPOJO();
	}
	
	@RequestMapping(value="/sellerView")
	public String sellerView() 
	{
		return "sellerView";
	}
	
	@RequestMapping(value= "/addProduct",method = RequestMethod.POST)
	public String addProdut(HttpServletRequest request,@ModelAttribute("productPOJO") ProductPOJO product,Model model,@RequestParam("imagea") MultipartFile ml) throws IOException, ServletException 
	{
		List<ProductPOJO> ls=productDAOImpl.getProductByCategory("elec");
		String filePath = "E:/Downloads/apache-tomcat-9.0.62/webapps/ROOT/prod/"+ml.getOriginalFilename();
		String filePath2 = "/prod/"+ml.getOriginalFilename();
		System.out.println(filePath);
		ml.transferTo(new File(filePath));
		System.out.println(filePath);
		for(ProductPOJO x:ls) 
		{
			System.out.println( x.getName()); 
		}
		product.setImage(filePath2);
		
		product.setId(productDAOImpl.getSize()+1);
		
		productDAOImpl.addProduct(product);
		model.addAttribute("prod",product);
		return ("tempaaaa");
	}
	
	
}
